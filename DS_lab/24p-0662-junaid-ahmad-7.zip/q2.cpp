#include <iostream> // queue follows last in last out . LILO
#include <limits>
using namespace std;// or First in first out

struct Node{
    Node* next;
    string data;
    
    Node(string val):data(val),next(nullptr){}
};

class queue{
    public:
    Node* front;
    Node* back;

    queue():front(nullptr),back(nullptr){}

    // Destructor to clean up memory
    ~queue() {
        while(front != nullptr) {
            Node* temp = front;
            front = front->next;
            delete temp;
        }
        back = nullptr;
    }
 
    void enqueue(string val){
        Node* newNode=new Node(val);
        if(!front && !back){
            front=newNode;
            back=newNode;
        }else{
            back->next=newNode;
            back=newNode;
        }
    }

    void dequeue(){
        if(front==nullptr || back==nullptr){
            return;
        }
        Node* temp=front;
        front=front->next;
        if(front == nullptr) {
            back = nullptr;
        }
        delete temp;
    }

    bool isEmpty() const {
        return front == nullptr;
    }

    string getfront(){
        if(isEmpty()) {
            cout<<"Queue is empty"<<endl;
            return "";
            // throw runtime_error("Queue is empty");
        }
        return front->data;
    }

    string getback(){
        if(isEmpty()) {
            cout<<"Queue is empty"<<endl;
            return "";
            // throw runtime_error("Queue is empty");
        }
        return back->data;
    }

    void display_queue(){
        if(isEmpty()) {
            cout << "Queue is empty" << endl;
            return;
        }
        Node* tn=front;
        while(tn){
            cout<<"Visitor "<<tn->data<<" now in queue"<<endl;
            tn=tn->next;
        }
    }
};

void enter_visitor_in_queue(queue &q){
    string name;
    cout<<"Enter the visitor's name: ";
    getline(cin,name);
    q.enqueue(name);
}

int inputValidator(){
    int a;
    while(true){
        cin>>a;
        if(cin.fail()){
            cin.clear();
            cin.ignore(numeric_limits<streamsize>::max(),'\n');
        }else{
            cin.ignore(numeric_limits<streamsize>::max(),'\n');
            return a;
        }
    }
}

void process_attraction_queue(queue &q, string attraction_name) {
    while(q.front != nullptr) {
        cout << "Visitor " << q.front->data << " now enjoying at the attraction " << attraction_name << endl;
        q.dequeue();
    }
}

int main() {
    queue ticketQ;
    queue rollerCoasterQ;
    queue roundWheelQ;
    queue motionRideQ;
    
    while(true) {
        cout << "Enter your choice:" << endl;
        cout << "1. Enter a visitor in tickets purchase queue." << endl;
        cout << "2. Sell a ticket." << endl;
        cout << "3. Process all queues." << endl;
        cout << "4. Exit" << endl;
        
        int choice = inputValidator();
        string visitor;
        int option;
        
        switch(choice) {
            case 1:
                enter_visitor_in_queue(ticketQ);
                break;
                
            case 2:
                if(ticketQ.isEmpty()) 
                {
                    cout<<"No visitors in ticket queue!"<<endl;
                    break;
                }
                
                visitor = ticketQ.getfront();
                cout << "Now selling ticket to: " << visitor << "..." << endl;
                cout << "Which attraction's ticket " << visitor << " wants?" << endl;
                cout << "1. Roller Coaster" << endl;
                cout << "2. Motion Ride" << endl;
                cout << "3. Round Wheel" << endl;
                
                option = inputValidator();
                
                switch(option) {
                    case 1:
                        rollerCoasterQ.enqueue(visitor);
                        cout << "Roller coaster ticket sold to " << visitor << endl;
                        break;
                    case 2:
                        motionRideQ.enqueue(visitor);
                        cout << "Motion ride ticket sold to " << visitor << endl;
                        break;
                    case 3:
                        roundWheelQ.enqueue(visitor);
                        cout << "Round wheel ticket sold to " << visitor << endl;
                        break;
                }
                ticketQ.dequeue();
                break;
                
            case 3:
                if(rollerCoasterQ.isEmpty() && motionRideQ.isEmpty() && roundWheelQ.isEmpty()) {
                    cout << "No visitors at any attraction sites!" << endl;
                    break;
                }
                process_attraction_queue(rollerCoasterQ, "roller coaster");
                process_attraction_queue(motionRideQ, "motion ride");
                process_attraction_queue(roundWheelQ, "round wheel");
                break;
                
            case 4:
                cout << "Thank you! Goodbye!" << endl;
                return 0;
                
            default:
                cout << "Invalid choice! Please try again." << endl;
                break;
        }
    }
    return 0;
}