#include <iostream>
#include <limits>
using namespace std;

class queue
{ // for circularity mod operator is used
    public:
    int front;
    int rear;
    string *arr;
    int capacity;
    int size; // additional funcitonality to keep track of number of patients in queue


    queue(int c) : front(-1), rear(-1), capacity(c), size(0)
    {
        arr = new string[c];
    }

    bool is_empty()
    {
        if (front == -1 && rear == -1)
        {
            return true;
        }
        else
        {
            return false;
        }
    }
    bool is_full(){
        // For circular queue approach that reserves one slot
        if (front == 0 && rear == capacity - 1) {
            return true;
        }
        if (front == rear + 1) {
            return true;
        }
        return false;
    }

    void addPatient(string v)
    {
            if (is_full())
            {
                cout << "the queue is full" << endl; 
                return;
            }
            else if (is_empty())
            { // it means front and rear will have the same value for the only element added
                front = 0;
                rear = 0;
            }
            else
            {
                rear = (++rear) % capacity;
            }
            arr[rear] = v;
            cout << v << " now waiting in the the queue \n " << endl;
            size++;
        
        }
    void remove_patient()
    {
        if (!is_empty())
        {
            string val=arr[front];
            if(front==rear){
                front=rear=-1;
            }else{
                front=(front+1)%capacity;           
            }
            size--;
            cout<<"patient sent to doctor"<<endl;
        }   else{
            cout<<"no patient "<<endl;
            return;
        }
    }
        
    string nextPatient()
    {
        if (is_empty())
        {
            return "The waiting list is empty ,no next patient \n";
        }
        else
            return "the next patient in queue :" + arr[front] + "\n";
    }
    string get_rear()
    {
        return arr[rear];
    }
    void display_queue()
{
    if (is_empty()) {
        cout << "Queue is empty" << endl;
        return;
    }
    
    int i = front;
    do {
        cout << arr[i] << endl;
        i = (i + 1) % capacity;
    } while (i != (rear + 1) % capacity);
}
};

void inputvalidator(int &a, string des)
{
    while (true)
    {
        cout << des << endl;
        cin >> a;
        if (cin.fail())
        {
            cout << "invalid input" << endl;
            cin.clear();
            cin.ignore(numeric_limits<streamsize>::max(), '\n');
        }
        else
        {
            return;
        }
    }
}
int main()
{
    int n;
    string des = "enter the number of seats in the waiting area";
    inputvalidator(n, des);
    queue q1(n);
    int choice;

    while (true)
    {
        cout << "Enter an option" << endl;
        cout << "1--Enter a patient in waiting queue" << endl;
        cout << "2--Send next patient to the doctor" << endl;
        cout << "3--See who is next" << endl;
        cout << "4--Exit"<<endl;
        cout << "patients count : "<<q1.size<<endl<<endl;
        cout<<"choose an option ";
        inputvalidator(choice, " ");

        if (choice == 1)
        {
            string name;
            cout << "patients name :" << endl;
            cin >> name;
            q1.addPatient(name);
        }
        else if (choice == 2)
        {
            q1.remove_patient();
        }
        else if (choice == 3)
        {
            cout << q1.nextPatient();
        }
        else if(choice==4)
        {
            break;
        }
        else{
            cout<<"invalid option ----"<<endl;
        }
    }
}