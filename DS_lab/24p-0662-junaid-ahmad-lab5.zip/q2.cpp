#include <iostream>
using namespace std;

struct Node
{
    string data;
    Node *next;
    Node(string data = "default") : data(data), next(nullptr) {}
};

class LinkedList
{
    Node *head;
    Node *tail;
    int count;

public:
    LinkedList() : head(nullptr), tail(nullptr), count(0) {}

    ~LinkedList()
    {
        if (head == nullptr)
            return;
        Node *current = head;
        Node *nextNode;
        do
        {
            nextNode = current->next;
            delete current;
            current = nextNode;
        } while (current != head);
    }

    void countSongs() // extra funcionality to count the number of songs in the playlist
    {
        if (head == nullptr)
        {
            cout << "The playlist is empty." << endl;
            return;
        }
        Node *temp = head;
        count = 0;
        do
        {
            count++;
            temp = temp->next;
        } while (temp != head);
        cout << "The number of songs in the list: " << count << endl;
    }

    void insertAtBeginning(string value)
    {
        Node *newNode = new Node(value);
        if (!head)
        {
            head = newNode;
            tail = newNode;
            tail->next = head;
        }
        else
        {
            newNode->next = head;
            head = newNode;
            tail->next = head;
        }
    }

    void insertAtEnd(string value)
    {
        Node *newNode = new Node(value);
        if (!head)
        {
            head = newNode;
            tail = newNode;
            tail->next = head;
        }
        else
        {
            tail->next = newNode;
            tail = newNode;
            tail->next = head;
        }
    }

    void insertAtPosition(string value, int position)
    {
        Node *newNode = new Node(value);
        if (position < 1)
        {
            cout << "Invalid position. Position should be >= 1." << endl;
            return;
        }

        if (position == 1)
        {
            insertAtBeginning(value);
            return;
        }

        Node *temp = head;
        for (int i = 1; i < position - 1 && temp; ++i)
        {
            temp = temp->next;
        }

        if (!temp)
        {
            cout << "Position out of range." << endl;
            delete newNode;
            return;
        }

        newNode->next = temp->next;
        temp->next = newNode;
        if (newNode->next == head)
        {
            tail = newNode;
        }
    }

    void deleteFromBeginning()
    {
        if (!head)
        {
            cout << "List is empty." << endl;
            return;
        }

        if (head == tail)
        {
            delete head;
            head = tail = nullptr;
            return;
        }

        Node *temp = head;
        head = head->next;
        tail->next = head;
        delete temp;
    }

    void deleteFromEnd()
    {
        if (!head)
        {
            cout << "List is empty." << endl;
            return;
        }

        if (head == tail)
        {
            delete head;
            head = tail = nullptr;
            return;
        }

        Node *curr = head;
        while (curr->next != tail)
        {
            curr = curr->next;
        }
        Node *temp = tail;
        tail = curr;
        tail->next = head;
        delete temp;
    }

    void searchForSong(string val)
    {
        if (!head)
        {
            cout << "List is empty." << endl;
            return;
        }

        bool found = false;
        Node *curr = head;
        do
        {
            if (curr->data == val)
            {
                found = true;
                cout << "Song found\nName: " << curr->data << endl;
                return;
            }
            curr = curr->next;
        } while (curr != head);

        if (!found)
        {
            cout << "Song not found" << endl;
        }
    }

    void deleteFromPosition(int position)
    {
        if (position < 1)
        {
            cout << "Position should be >= 1." << endl;
            return;
        }

        if (position == 1)
        {
            deleteFromBeginning();
            return;
        }

        Node *temp = head;
        for (int i = 1; i < position - 1 && temp; ++i)
        {
            temp = temp->next;
        }

        if (!temp || !temp->next)
        {
            cout << "Position out of range." << endl;
            return;
        }

        Node *nodeToDelete = temp->next;
        temp->next = temp->next->next;

        if (nodeToDelete == tail)
        {
            tail = temp;
        }

        delete nodeToDelete;
    }

    void updateSong(string oldName, string newName)
    {
        if (!head)
        {
            cout << "List is empty." << endl;
            return;
        }

        Node *curr = head;
        bool found = false;

        do
        {
            if (curr->data == oldName)
            {
                curr->data = newName;
                found = true;
                cout << "Song updated successfully." << endl;
                return;
            }
            curr = curr->next;
        } while (curr != head);

        if (!found)
        {
            cout << "Song not found, update failed." << endl;
        }
    }

    void display() const
    {
        if (!head)
        {
            cout << "List is empty." << endl;
            return;
        }

        Node *temp = head;
        int i = 1;
        cout << "List of songs you have on the playlist:" << endl;

        do
        {
            cout << i << "- " << temp->data << endl;
            temp = temp->next;
            i++;
        } while (temp != head);
    }

    void playSong() 
    {
        if (head == nullptr)
        {
            cout << "Playlist is empty." << endl;
            return;
        }

        Node *current = head;
        cout << "Now playing: " << current->data << endl;
        string input;
        while (true)
        {
            cout << "Enter 'next' to play the next song or 'stop' to stop: ";
            cin >> input;
            if (input == "next")
            {
                current = current->next;
                cout << "Now playing: " << current->data << endl;
            }
            else if (input == "stop")
            {
                break;
            }
            else
            {
                cout << "Invalid input." << endl;
            }
        }
    }
};

int main()
{
    LinkedList list;
    while (true)
    {
        cout << "\nWelcome to the Music Playlist:" << endl;
        cout << "Options:" << endl;
        cout << "1. Add a song" << endl;
        cout << "2. Delete a song" << endl;
        cout << "3. Search a song" << endl;
        cout << "4. Update song name" << endl;
        cout << "5. Print playlist" << endl;
        cout << "6. Play" << endl;
        cout << "7. Total songs in the playlist" << endl;
        cout << "8. Exit" << endl;

        int input;
        cin >> input;
        cin.ignore();

        switch (input)
        {
        case 1:
        {
            string song;
            cout << "Enter the song name: ";
            getline(cin, song);
            cout << "How much favorite is it?\n1--Most favorite\n2--Least favorite\n3--Specify your favorite level" << endl;
            int choice;
            cin >> choice;

            switch (choice)
            {
            case 1:
                list.insertAtBeginning(song);
                break;
            case 2:
                list.insertAtEnd(song);
                break;
            case 3:
            {
                int pos;
                cout << "Choose position between 2-5: ";
                cin >> pos;
                list.insertAtPosition(song, pos);
                break;
            }
            default:
                cout << "Invalid choice! Try again." << endl;
            }
            break;
        }

        case 2:
        {
            int position;
            cout << "Enter the position from which you want to delete the song: ";
            cin >> position;
            list.deleteFromPosition(position);
            break;
        }

        case 3:
        {
            string search;
            cout << "Enter the name of the song you want to search: ";
            getline(cin, search);
            list.searchForSong(search);
            break;
        }

        case 4:
        {
            string oldName, newName;
            cout << "Enter the name of the song you want to update: ";
            getline(cin, oldName);
            cout << "Enter the new song name: ";
            getline(cin, newName);
            list.updateSong(oldName, newName);
            break;
        }

        case 5:
            list.display();
            break;

        case 6:
            list.playSong();
            break;
        case 7:
            list.countSongs();
            break;

        default:
            cout << "Invalid option! Please try again." << endl;
        }
    }
}
