#include <iostream>
using namespace std;

struct Node
{
    string description;
    int flag;
    Node *next;
    Node *prev;
    Node(string x = "-") : description(x), flag(0), next(nullptr), prev(nullptr) {}
};
class Todolist
{
public:
    Node *head;
    Todolist() : head(nullptr) {}

    void Add_task(string task, int priority = 1)
    {
        Node *newNode = new Node(task);
        if (priority <= 0)
        {
            cout << "invalid priority for the task" << endl;
            return;
        }
        else if (priority == 1)
        {
            if (head == nullptr)
            {
                head = newNode;
            }
            else
            {
                newNode->next = head;
                head->prev = newNode;
                head = newNode;
            }
            return;
        }

        Node *curr = head;
        for (int i = 1; curr != nullptr && i < priority - 1; i++)
        {
            curr = curr->next;
        }
        if (curr == nullptr)
        {
            cout << "invalid priority" << endl;
            return;
        }
        newNode->next = curr->next;
        newNode->prev = curr;
        if (curr->next != nullptr)
        {
            curr->next->prev = newNode;
        }
        curr->next = newNode;
    }

    void displayList()
    {
        if (!head)
        {
            cout << "the list is empty" << endl;
            return;
        }
        Node *curr = head;
        char input;
        cout << "Want to display the list forward or reverse? (F/R)" << endl;
        cin >> input;

        if (input == 'F' || input == 'f')
        { // Forward traversal
            int i = 1;
            while (curr != nullptr)
            {
                cout << i << ") " << curr->description << "  " << endl;
                if (curr->flag == 1)
                {
                    cout << "Task is completed" << endl;
                }
                else
                {
                    cout << "Task pending" << endl;
                }
                cout << "---------------------------" << endl;
                curr = curr->next;
                i++;
            }
        }

        else if (input == 'R' || input == 'r')
        { // Reverse traversal
            if (head == nullptr)
            {
                cout << "List is empty!" << endl;
                return;
            }

            while (curr->next != nullptr)
            {
                curr = curr->next;
            }

            int i = 1;
            while (curr != nullptr)
            {
                cout << i << ") " << curr->description << "  " << endl;
                if (curr->flag == 1)
                {
                    cout << "Task is completed" << endl;
                }
                else
                {
                    cout << "Task pending" << endl;
                }
                cout << "---------------------------" << endl;
                curr = curr->prev;
                i++;
            }
        }

        else
        {
            cout << "Invalid choice" << endl;
        }
    }

    void marktaskcompleted()
    {
        if (!head)
        {
            cout << "the list is empty" << endl;
            return;
        }

        Node *dis = head;
        int i = 1;
        while (dis != nullptr)
        {
            cout << i << ") " << dis->description << "  " << endl;
            if (dis->flag == 1)
            {
                cout << "Task is completed" << endl;
            }
            else
            {
                cout << "Task pending" << endl;
            }
            cout << "---------------------------" << endl;
            dis = dis->next;
            i++;
        }
        int n;
        cout << "choose which task you wanna mark complete " << endl;
        cin >> n;
        Node *curr = head;
        if (n <= 0)
        {
            cout << "invalid input ";
            return;
        }

        for (int i = 1; i < n && curr != nullptr; i++)
        {
            curr = curr->next;
        }

        if (curr == nullptr)
        {
            cout << "invalid input condition 2" << endl;
            return;
        }
        curr->flag = 1;
    }
    void remove_completed()
    {
        if (!head)
        {
            cout << "the list is empty" << endl;
            return;
        }
        Node *curr = head;

        while (curr != nullptr)
        {
            if (curr->flag == 1)
            {
                if (curr == head)
                {
                    Node *temp1 = curr;
                    head = curr->next;
                    if (head != nullptr)
                    {
                        head->prev = nullptr;
                    }
                    curr = head;
                    delete temp1;
                }
                else
                {
                    Node *temp2 = curr;
                    curr = curr->next;

                    temp2->prev->next = curr;
                    if (curr != nullptr)
                    {
                        curr->prev = temp2->prev;
                    }

                    delete temp2;
                }
            }
            else
            {
                curr = curr->next; // Move only if no deletion happened
            }
        }

        cout << "-- Tasks deleted . New list after deleting the completed tasks --" << endl;

        Node *temp = head;
        int i = 1;
        while (temp != nullptr)
        {
            cout << i << ") " << temp->description << "  " << endl;
            if (temp->flag == 1)
            {
                cout << "Task is completed" << endl;
            }
            else
            {
                cout << "Task pending" << endl;
            }
            cout << "---------------------------" << endl;
            temp = temp->next;
            i++;
        }
    }
};
int main()
{
    Todolist list;
    int choice;

    while (true)
    {
        cout << "---- TODO LIST ----" << endl;
        cout << "\n 1-- add task" << endl;
        cout << "\n 2-- mark complete" << endl;
        cout << "\n 3-- delete completed tasks" << endl;
        cout << "\n 4-- display the list" << endl;
        cout << "\n 5-- exit" << endl
             << endl;
        cin >> choice;

        switch (choice)
        {
        case 1:
        {
            string str;
            int p;
            cout << "Enter the task:" << endl;
            cin.ignore(); // Ignore the newline character left in the buffer
            getline(cin, str);
            cout << "enter priority of the task" << endl;
            cin >> p;
            list.Add_task(str, p);
            break;
        }
        case 2:
            list.marktaskcompleted();
            break;

        case 3:
            list.remove_completed();
            break;

        case 4:
            list.displayList();
            break;

        case 5:
            cout << "Exiting..." << endl;
            return 0;

        default:
            cout << "Invalid option" << endl;
            break;
        }
    }

    return 0;
}