#include <iostream>
#include <vector>
using namespace std;

struct Node{
    Node* next;
    int val;
    Node(int v):val(v),next(nullptr){}

};
class stack{
    private:
    Node* top;
    public:
    stack():top(nullptr){}

    void push(int val){
        Node* newNode=new Node(val);
        if(!top){
            top=newNode;
        }
        else{
            newNode->next=top;
            top=newNode;
        }
    }

    void pop(){
        if(!top){
            cout<<"the stack is empty "<<endl;
            return;
        }
        else{
            Node* temp=top;
            top=top->next;
            delete temp;
        }
    }

    int peek()   
    {
        return top ? top->val : -1; // ternery operator is used here 
    }
    
    
    void display(){
        
        for(Node* curr=top ; curr!=nullptr ; curr=curr->next){ 
            cout<<curr->val<<endl;
        }
        cout<<endl;
    }
    
    void swap(int &a, int &b){
        push(a);
        push(b);
        a=peek();
        pop();
        b=peek();
    }

};

int main(){
    int x;
    int y;
    cout<<"enter value for variable no 1 let call it x :"<<endl;
    cin>>x;
    cout<<"enter value for variable no 2 let call it y :"<<endl;
    cin>>y;

    cout<<"the value of  x  :"<<x<<" \n the value of y : "<<y<<endl;
    stack st;
    st.swap(x,y);
    cout<<"the value after swap"<<endl;
    cout<<" x : "<<x<<endl;
    cout<<" y : "<<y<<endl;
    return 0;
}