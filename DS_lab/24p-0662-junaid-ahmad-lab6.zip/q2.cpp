#include <iostream>
#include <string>
using namespace std;

struct Stack
{
    char *arr;
    int top;
    int capacity;

    Stack(int val) : capacity(val), top(-1)
    {
        arr = new char[capacity];
    }

    

    void push(char val)
    {
        if (top < capacity - 1)
        {
            arr[++top] = val;
            // cout << "Pushed: " << val << endl;
        }
        else
        {
            cout << "Stack Overflow!" << endl;
        }
    }

    void pop()
    {
        if (top >= 0)
        {
            arr[top--];
            // cout << "Popped: " << arr[top--] << endl;
        }
        else
        {
            cout << "Stack Underflow!" << endl;
        }
    }

    int peek()
    {
        if (top >= 0)
        {
            return arr[top];
        }
        else
        {
            cout << "Stack is empty!" << endl;
            return -1;
        }
    }

    bool isEmpty()
    {
        return top == -1;
    }

    bool isFull()
    {
        return top == capacity - 1;
    }

    void display()
    {
        if (isEmpty())
        {
            cout << "Stack is empty!" << endl;
            return;
        }
        cout << "Stack elements:\n";
        for (int i = top; i >= 0; i--)
        {
            cout << arr[i] << endl;
        }
    }
    void reverseFtn(string &x){
        int i=0;
    while(i<x.length()){
        push(x[i]);
        i++;
    }
    i = 0;
    while (!isEmpty()) { 
        x[i] =peek();
        pop();
        i++;
    }
        
    }
    ~Stack()
    {
        delete[] arr; 
    }
};

int main()
{
    string input;
    cout<<"enter a string "<<endl;
    getline(cin,input);
    cout<<"original : "<<input <<endl;
    Stack st(100);
    st.reverseFtn(input);
    cout<<"reverse : "<<input<<endl;
    
    return 0;
}
