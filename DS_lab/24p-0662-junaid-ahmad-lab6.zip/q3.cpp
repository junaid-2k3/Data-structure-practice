#include <iostream>
using namespace std;

struct Node {
    char val;
    Node* next;

    Node(char v) : val(v), next(nullptr) {}
};

class Stack {
public:
    Node* top;

    Stack() : top(nullptr) {}

    void push(char val) {
        Node* newNode = new Node(val);
        newNode->next = top; 
        top = newNode;
    }

    char pop() {
        if (top == nullptr) {
            cout << "Stack is empty!" << endl;
            return '\0';
        }
        char poppedValue = top->val; 
        Node* temp = top;
        top = top->next;
        delete temp;
        return poppedValue;
    }

    char peek() {
        return (top != nullptr) ? top->val : '\0';
    }

    bool isEmpty() {
        return top == nullptr;
    }

    void display() {
        Node* curr = top;
        while (curr != nullptr) {
            cout << curr->val;
            curr = curr->next;
        }
        cout << endl;
    }

    string StackString() {
        string result = "";
        Node* curr = top;
        while (curr != nullptr) {
            result = curr->val + result; // add the the top to the left of the string ,Reverse order for correct display
            curr = curr->next;
        }
        return result;
    }
};

void Undo_Redo(Stack &st1, Stack &st2, string str) {
    // Push the string into stack1
    for (char ch : str) {
        st1.push(ch);
    }

    char choice;
    while (true) {
        cout << "Current String: " << st1.StackString() << endl;
        cout << "Undo (U/u) | Redo (R/r) | Exit (E/e): ";
        cin >> choice;

        if (choice == 'U' || choice == 'u') {
            if (!st1.isEmpty()) {
                st2.push(st1.pop());
            } else {
                cout << "Nothing to undo!" << endl;
            }
        } else if (choice == 'R' || choice == 'r') {
            if (!st2.isEmpty()) {
                st1.push(st2.pop());
            } else {
                cout << "Nothing to redo!" << endl;
            }
        } else if (choice == 'E' || choice == 'e') {
            break;
        } else {
            cout << "Invalid choice! Try again." << endl;
        }
    }
}

int main() {
    Stack stack1, stack2;
    string input;
    
    cout << "Enter a string: ";
    getline(cin, input);

    Undo_Redo(stack1, stack2, input);

    return 0;
}
